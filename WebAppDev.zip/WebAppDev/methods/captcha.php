<?php
//Code taken from http://php.net/manual/en/function.imagestring.php
$im = imagecreatefromjpeg('../files/captcha.jpg');
include 'functions.php';
// White background and blue text
$bg = imagecolorallocate($im, 0, 0, 0);
$textcolor = imagecolorallocate($im, 0, 0, 0);
if(session_id() != ''){
    $text = generateRandomSequence('captcha');
    $_SESSION['captcha'] = $text;
}

// Write the string at the top left
imagestring($im, 10, 10, 10, $text, $textcolor);

// Output the image
header('Content-type: image/png');

imagepng($im);
imagedestroy($im);
?>