<?php session_start(); //starts the session and sends the session headers.
ob_start();
include 'dbController.php'; //includes the database controller to access the database functionality.
    if(!is_loggedin())
    {
        invalid_login_timeout();
    }


$applicationRoot = $_SERVER["DOCUMENT_ROOT"].'/WebAppDev'; 
define('SCRIPTS',$applicationRoot.'/scripts');
define('FILES',$applicationRoot.'/files');
define('TEMPLATES',$applicationRoot.'/templates');
define('VIEWS',$applicationRoot.'/templates/views');
define('METHODS',$applicationRoot.'/methods');

    function get($template){ //function to dynamically get the content of file.
        if(file_exists('templates/'.$template.'.php')){ //checks if the required file exists.
            require('templates/'.$template.'.php'); //get or fetch the file content.
        }
        else{
            echo 'Template Error'; //if file does not exist, throws an error.
        }
    }
    function doNavigation($pages = array()){ //generates 
        echo '<nav id="primary-navigation" class="mobile-nav"><ul>';
            foreach($pages as $nameLink){
                echo '<li><a href="'.$nameLink[1].'">'.$nameLink[0].'</a></li>';
            } 
        echo '</ul></nav>';
    }
    function generateRandomSequence($type){
        if($type == "captcha"){
            $alphaNumeric = "abcdefghijklmnopqrstuvwxyz0123456789";
        }
        else {
            $alphaNumeric = "ABIQRSTUVWXYZ012CDEFGH34567JKLMNOP89";
        }
        $randomArray = str_split($alphaNumeric);
        shuffle($randomArray);
        $random = substr(implode($randomArray),4,-27);
        return $random;
    }
    function mailUser($email,$sub,$mes){
        $to      = $email;
        $subject = $sub;
        $message = $mes;
        $headers = 'From: webmaster@example.com' . "\r\n" .
                    'Reply-To: webmaster@example.com' . "\r\n" .
                    'X-Mailer: PHP/'.phpversion();

        echo $to;
        echo $subject;
        echo $message;
        return mail($to, $subject, $message, $headers);
        
    }
    function is_loggedin(){
        if(isset($_SESSION['auth']) && isset($_SESSION['username'])){
            if($_SESSION['auth'] == true && is_user($_SESSION['username'])){
                return true;
            }
            else{
                return false;
            }
        }
        return false;
    }
    function get_title(){ //Function to create a page title dynamically by given get request.
        if(isset($_GET['p'])){ //checks if a get request is set as p.
            $text = "> ".ucwords($_GET['p']); //creates a fancy string, ucwords capitalises the first letter of the string.
            echo $text; //prints the string.
        }
    } //end function get_title
    function compile_days($days){ //takes the array and makes an string of selected days; seperated by commas/
        $d = NULL; //sets the returning variable to NULL, so it can be updated in the loop and returned outside the loop.
        foreach($days as $day){ //iterates through for each value of day while assigning every single value to $day.
            $d .= $day.', '; //appends on the string.
        }
        return rtrim($d,", "); //returns the string after removing the last comma.
    } //end function compile_days
    function is_email($email){ // function to check if an string is an email, takes an string as parameter.
        if(filter_var($email, FILTER_VALIDATE_EMAIL)) { //if this premise is true it determines that provided email was a valid email.
            return true; //return true, valid email.
        }
        else {
            return false; //return false,invalid email.
        }
    } //end function is_email
    function do_error(){
            if(isset($_SESSION['update'])){
            switch($_SESSION['update']){
            case 'email':
                echo '<div class="message-box green">';
                echo 'Email Updated Successfully';
                echo '</div>';
            break;
            case 'emailerror':
                echo '<div class="message-box red">';
                echo 'Invalid Email - Email not updated!';
                echo '</div>';
            break;
             case 'passworderror':
                echo '<div class="message-box red">';
                echo 'Invalid Current Password - Password not updated!';
                echo '</div>';
            break;
            case 'car':
                echo '<div class="message-box green">';
                echo 'Vehicle added successfully!';
                echo '</div>';
            break;
            case 'carerror':
                echo '<div class="message-box red">';
                echo 'Vehicle not updated!';
                echo '</div>';
            break;
            case 'required':
                echo '<div class="message-box red">';
                echo 'All fields are required! Data not added.';
                echo '</div>';
            break;
            case 'password':
                echo '<div class="message-box green">';
                echo 'Password changed successfully';
                echo '</div>';
            break;
            case 'fiveplus':
                echo '<div class="message-box red">';
                echo 'Not more than five images are allowed';
                echo '</div>';
            break;
            case 'imagesadded':
                echo '<div class="message-box green">';
                echo 'Images added!';
                echo '</div>';
            break;
            case 'postadded':
                echo '<div class="message-box green">';
                echo 'Post Added Successfull.';
                echo '</div>';
            break;
            case 'imageDelete':
                echo '<div class="message-box green">';
                echo 'Image deleted Successfully.';
                echo '</div>';
            break;
            case 'sizeortype':
                echo '<div class="message-box red">';
                echo 'Invalid image size or type, Try again.';
                echo '</div>';
            break;
            case 'invalidpost':
                echo '<div class="message-box red">';
                echo 'Invalid post, Try again.';
                echo '</div>';
            break;
        }
        unset($_SESSION['update']);
        }
    }
function image_type_check($type){
    $validImageTypes = array("image/png", "image/bmp", "image/gif", "image/jpg", "image/jpeg");
    if (in_array($type, $validImageTypes)){
        return true;
    }
    else{
        return false;
    }
}
function image_size_check($size){
    $maximumsize = 5000;
    if($size >= $maximumsize){
        return true;
    }
    else{
        return false;
    }
}
function invalid_login_timeout(){ 
    if(!isset($_SESSION['time']) && !is_loggedin()){
        $_SESSION['time'] = date('+i',strtotime("+3 minutes"));
    }
    if(isset($_SESSION['time'])){
        if($_SESSION['time'] < (date('i')))
        {
            session_destroy();
        }
    }
}
function do_posts_limit(){
    $page_number = 0;
    if(isset($_GET['page'])){
        if($_GET['page']>0){
            $page_number=intval($_GET['page'])-1; 
        }
    }
    $first_limit = $page_number*10;
    $second_limit = $first_limit+10;
    return $first_limit.','.$second_limit;
}
function do_not_found(){
    header("HTTP/1.0 404 Not Found");
    header("location: ?p=404");
    exit();
}
function do_pagination(){
    $total_posts = count(get_posts(false,false,NULL));
    $first_page = 1;
    $last_page = ceil($total_posts/10);
    $current_page = NULL;
    $numbers = '';
    $next_btn = '';
    $prev_btn = '';
    $error = false;
    if(isset($_GET['page'])){
             $current_page = intval($_GET['page']); 
    }
    if($current_page > $last_page || $current_page == 0){
        do_not_found();
    }
    $initEnd = $current_page;
    $lastEnd = $current_page;
    $counter = 10;
    $inc_constant = 10;
    if(($current_page - $first_page) >= 10 || ($current_page - 10) < 0 && ($current_page != 1)){
        $prev_btn = '<a href="?p=explore&page='.($current_page-1).'">'.'< Previous</a>'.' ... ';
    }
    for($i=1;$i<=$last_page;$i++){
        if($counter != 0){
            $counter--;
            if($current_page % 10 == 0 && ($current_page <= $last_page)){
                $pages = intval($current_page)+$i;
                if($current_page == ($pages)){
                     $numbers .= '<a id="current" class="nump" href="?p=explore&page='.$pages.'"> '.$pages.'</a>';
                }
                else{
                    $numbers .= '<a class="nump" href="?p=explore&page='.$pages.'"> '.$pages.'</a>';
                }
            }
            else{
                $error = true;
            }  
        }
    }
    if(($current_page+10) != $last_page){
        $next_btn = ' ... '.'<a href="?p=explore&page='.($current_page+1).'">'.'Next ></a>';
    }
    if(!$error){
       return $prev_btn.$numbers.$next_btn;
    }
    else{
        $pages = intval($current_page);
        while(($initEnd % 10) != 0){
            $initEnd = $initEnd-1;
        }
        while(($lastEnd % 10) != 0 || $initEnd == $lastEnd){
            if($last_page <= $lastEnd){
                break;
            }
             $lastEnd = $lastEnd+1;
        }
        for($i=$initEnd+1;$i<=$lastEnd;$i++){  
                if($current_page == ($i)){
                    $numbers .= '<a id="current" class="nump" href="?p=explore&page='.$i.'"> '.$i.'</a>';
                }
                else{
                    $numbers .= '<a class="nump" href="?p=explore&page='.$i.'"> '.$i.'</a>';
                }
        }
        if($last_page < 10){
            return $numbers;
        }
        else{
            return $prev_btn.$numbers.$next_btn;
        }
    }
}

?>