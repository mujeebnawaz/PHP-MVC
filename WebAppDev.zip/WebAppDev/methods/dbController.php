<?php
function openConnect(){ // Function for directly connecting to the database without providing any details
    $databaseLink = mysqli_connect( //MySql procedural function to connect to the database
        "localhost",  //Host
        "root",  //Username
        "root", //Password
        "webAppDev", //Database Name
        "8889" //Port
    );
    if (mysqli_connect_errno()) 
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    return $databaseLink;
}
function escape_chars($query){
    //Uses mysqli_real_escape_string and returns a sanitised string, It serves two purposes:
    //1. Short Name.
    //2. We do not need to open a database connection to sanitise if use this function.

    $databaseLink = openConnect(); //opens database connection; and stores the reference of the connection to a variable.
    $escaped = mysqli_real_escape_string($databaseLink,$query); //passes the database connection reference and unsanitised query.
    mysqli_close($databaseLink); //closes the database connection.
    return $escaped; //return the sanitised string.
}
function register_user($username,$password,$email,$licence){
    //sanitises the user given input and execute an SQL query to add users to the database. 
    //Also triggers the email for user verification.
    $user = escape_chars($username);
    $pass = escape_chars(md5($password));
    $u_email = escape_chars($email);
    $licence = escape_chars($licence);
    $databaseLink = openConnect(); //opens database connection; and stores the reference of the connection to a variable.
    if(!is_user($user)){ //checks if user does not exist
        $verification = generateRandomSequence("verification"); //generates a random verification code, if user can be registered
        $query = "INSERT INTO registeredMembers (username,password,email,verification,drivingLicence) VALUES ('".$user."','".$pass."','".$u_email."','".$verification."','".$licence."')"; // que
        if(mysqli_query($databaseLink,$query)){ //executes the query, and checks if query is executes
            return 0;    //if query executes successfully, returns 0 
        }
        else{
            return 1; // if query cannot be executed return 1
        }
    }
    else{
        return 2; //if User exists returns 2
    }
    mysqli_close($databaseLink); //closes the database connection
}
function add_car($make,$model,$registration,$insurance,$userid){
    $make = escape_chars($make);
    $model = escape_chars($model);
    $registration = escape_chars($registration);
    $insurance = escape_chars($insurance);
    $databaseLink = openConnect(); //opens database connection; and stores the reference of the connection to a variable.
    $query = "INSERT INTO cars (make,model,registrationNumber,insuranceStatus,member_id) VALUES ('".$make."','".$model."','".$registration."','".$insurance."','".$userid."')"; 
    if(mysqli_query($databaseLink,$query)){ //executes the query, and checks if query is executes
            return true;    //if query executes successfully, returns true; car added.
        }
    else{
        return false; // if query cannot be executed return false. Car not added.
    }
     mysqli_close($databaseLink); //closes the database connection
}

function do_login($username,$password){
    $username = escape_chars($username);
    $password = escape_chars(md5($password));
    $query = "SELECT username,password FROM registeredMembers WHERE username = '".$username."' AND password = '".$password."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_num_rows($results);
    if($values > 0){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function get_user(){
    
}
function is_user($username){
    $username = escape_chars($username);
    $query = "SELECT username FROM registeredMembers WHERE registeredMembers.username = '".$username."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_num_rows($results);
    if($values > 0){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function is_post($postid){
    $postid = escape_chars($postid);
    $query = "SELECT post_id FROM posts WHERE post_id = '".$postid."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_num_rows($results);
    if($values > 0){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function is_verified($username){
    $username = escape_chars($username);
    $query = "SELECT status FROM registeredMembers WHERE registeredMembers.username = '".$username."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_fetch_assoc($results);
    if($values["status"] == 1){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function get_member_id($username){
    $username = escape_chars($username);
    $query = "SELECT member_id FROM registeredMembers WHERE registeredMembers.username = '".$username."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_fetch_assoc($results);
    return $values['member_id'];
    mysqli_close($databaseLink); //closes the database connection
}
function do_verify($username,$verificationCode){
    $username = escape_chars($username);
    $verificationCode = escape_chars($verificationCode);
    $query = "UPDATE registeredMembers SET status = '1' WHERE registeredMembers.username = '".$username."' AND registeredMembers.verification = '".$verificationCode."'" ;
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_affected_rows($databaseLink);
    if($values == 1){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function get_post_selection($memberid){
    $memberid = escape_chars($memberid);
    $preslected = escape_chars($preselected);
    $postid = escape_chars($postid);
    $databaseLink = openConnect();
    $query = "SELECT startingPoint,post_id FROM posts WHERE member_id = '".$memberid."'";
    $results = mysqli_query($databaseLink,$query);
        while($values = mysqli_fetch_assoc($results)){
            echo '<option value="'.$values['post_id'].'">'.$values['startingPoint'].'</option>';
        }
    mysqli_close($databaseLink); //closes the database connection
}
function make_post($start,$end,$times,$days,$function,$message,$memberid){
    $start = escape_chars($start); 
    $end = escape_chars($end);
    $times = escape_chars($times);
    $days = escape_chars($days);
    $function = escape_chars($function);
    $message = escape_chars($message);
    $memberid = escape_chars($memberid);
    $query = "INSERT INTO posts (startingPoint,destination,travelTimes,days,obtainProvide,message,member_id) VALUES ('".$start."','".$end."','".$times."','".$days."','".$function."','".$message."','".$memberid."')"; 
    $databaseLink = openConnect();
    if(mysqli_query($databaseLink,$query)){ //executes the query, and checks if query is executes
        $_SESSION['recentpid'] = mysqli_insert_id($databaseLink);
        return 0;  //if query executes successfully, returns 0 
    } 
    else{
        return 1; // if query cannot be executed return 1
    }
    mysqli_close($databaseLink); //closes the database connection
}

function get_posts($filters,$all,$specific){
    if(!$filters){
        if($all){
            $query = "SELECT * FROM posts,registeredMembers WHERE posts.member_id = registeredMembers.member_id AND post_status = 1 LIMIT ".do_posts_limit();
        }
        if($specific != NULL){
            $specific = escape_chars($specific);
            $query = "SELECT * FROM posts,registeredMembers WHERE posts.member_id = registeredMembers.member_id AND post_status = 1 AND post_id =".$specific;
        }
        else{
            $query = "SELECT * FROM posts,registeredMembers WHERE posts.member_id = registeredMembers.member_id AND post_status = 1";
        }
    }
    else{
        $filters= escape_chars($filters);
        $filter = explode(":",$filters);
        switch($filter[0]){
            case "message":
                $query = "SELECT * FROM posts,registeredMembers WHERE message LIKE '%".$filter[1]."%' AND posts.member_id = registeredMembers.member_id AND post_status = 1";
            break;
        }
    }
    $databaseLink = openConnect(); 
    $results = mysqli_query($databaseLink,$query);
    if(mysqli_num_rows($results) > 1){
        while($row = $results->fetch_assoc()){
            $rows[] = $row;
        }
        return $rows;
    }
    else{
        $values = mysqli_fetch_assoc($results);
        return $values;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function get_user_($userid,$function){
    $userid = escape_chars($userid);
    $values = NULL;
    if($function == "details"){
        $query = "SELECT * FROM registeredMembers WHERE member_id ='".$userid."'";
    }
    else if($function == "cars"){
        $query = "SELECT * FROM cars WHERE member_id ='".$userid."'";
    }
    $databaseLink = openConnect(); 
    $results = mysqli_query($databaseLink,$query);
    if(mysqli_num_rows($results) > 1){
        while($row = $results->fetch_assoc()){
            $rows[] = $row;
        }
        return $rows;
    }
    else{
        $values = mysqli_fetch_assoc($results);
        return $values;
    }
    
    mysqli_close($databaseLink); //closes the database connection
}
function update_email($username,$newEmail){
    $username = escape_chars($username);
    $newEmail = escape_chars($newEmail);
    $query = "UPDATE registeredMembers SET email = '".$newEmail."' WHERE username ='".$username."'";
    $databaseLink = openConnect(); 
    mysqli_query($databaseLink,$query);
    if(mysqli_affected_rows($databaseLink) > 0){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function change_password($currentPassword,$newPassword,$username){
    $currentPassword = escape_chars(md5($currentPassword));
    $newPassword = escape_chars(md5($newPassword));
    $username = escape_chars($username);
    $query = "UPDATE registeredMembers SET password ='".$newPassword."' WHERE username = '".$username."' AND password = '".$currentPassword."'";
    echo $query;
    $databaseLink = openConnect(); //opens database connection; and stores the reference of the connection to a variable.
    mysqli_query($databaseLink,$query);
    if(mysqli_affected_rows($databaseLink) > 0){
        return true;
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function generate_image_name($postid){
    $postid = escape_chars($postid);
    $query = "SELECT image_id FROM images ORDER BY image_id DESC LIMIT 1";
    $databaseLink = openConnect(); //opens database connection; and stores the reference of the connection to a variable.
    $results = mysqli_query($databaseLink,$query);
    $value  = mysqli_fetch_assoc($results);
    $newvalue = intval($value['image_id'])+1;
    $image_name = $postid."-".$newvalue."-".get_member_id($_SESSION['username']);
    return $image_name;
}
function insert_image($postid,$imagepath){
    $postid = escape_chars($postid);
    $query = "INSERT INTO images (imagePath, post_id) VALUES ('".$imagepath."','".$postid."')";
    echo $query;
    $databaseLink = openConnect(); //opens database connection; and stores the reference of the connection to a variable.
    if(mysqli_query($databaseLink,$query)){ //executes the query, and checks if query is executes
            return true;    //if query executes successfully, returns true; image added.
        }
    else{
        return false; // if query cannot be executed return false. image not added.
    }
     mysqli_close($databaseLink); //closes the database connection
}
function delete_image($imageid){
    $imageid = escape_chars($imageid);
    $query = "UPDATE images SET is_active = 0 WHERE image_id ='".$imageid."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    $values = mysqli_affected_rows($databaseLink);
    if($values == 1){
        $query = "SELECT imagePath FROM images WHERE image_id ='".$imageid."'";
        $results = mysqli_query($databaseLink,$query);
        $value  = mysqli_fetch_assoc($results);
        if(file_exists($value['imagePath'])){
            unlink($value['imagePath']);
            $_SESSION['update'] = "imageDelete";
            return true;
        }
    }
    else{
        return false;
    }
    mysqli_close($databaseLink); //closes the database connection
}
function get_image_url($postid){
    $postid = escape_chars($postid);
    $query = "SELECT imagePath,image_id,post_id FROM images WHERE is_active = 1 AND post_id ='".$postid."'";
    $databaseLink = openConnect();
    $results = mysqli_query($databaseLink,$query);
    if(mysqli_num_rows($results) > 1){
        while($row = $results->fetch_assoc()){
            $rows[] = $row;
        }
        return $rows;
    }
    else{
        $values = mysqli_fetch_assoc($results);
        return $values;
    }
    mysqli_close($databaseLink); //closes the database connection
}
?>