<?php 
if(isset($_GET['deleteimg'])){
    delete_image($_GET['deleteimg']);
}
if(isset($_GET['postid'])){
    $post = get_posts(false,false,$_GET['postid']); 
?>
     <div class="post">
        <div class="user">
            <h2>User Details</h2><br>
            <span class="explore-username">Username: <b><?= $post['username']; ?></b></span><br/>
            <span class="explore-email">Email: <b><?= $post['email']; ?></b></span><br/>
            <span class="drivingLicence">Has driving licence?: <b><?= $post['drivingLicence']; ?></b></span><br/>
        </div><br/>
        <div class="journey">
            <h2>Journey Details</h2><br/>
            <span class="startingPoint">Starting Point:<b><?= $post['startingPoint']; ?></b></span><br/>
            <span class="startingPoint">Destination: <b><?= $post['destination']; ?></b></span><br/>
            <span class="travelTime">Traveling time: <b><?= $post['travelTimes']; ?></b></span><br/>
            <span class="travelDays">Days: <b><?= $post['days']; ?></b></span><br/>
            <span class="obtainP">Wants to <b><?= ($post['obtainProvide'])? 'Obtain':'Provide'; ?></b> the lift.</span><br/>
            <span>Message: <br/><b><?= $post['message']; ?></b></span>
        </div>
    </div>
    <h2>Images</h2>
    <div class="images">
        <?php 
            $images = get_image_url($post['post_id']);
            if($images != NULL){
                echo '<br/><div class="intro-buttons"><a style="    width: 140px;" href="/WebAppDev/?p=upload-Image">Upload-Image</a></div>';
                foreach($images as $image){
                    if(file_exists($image['imagePath'])){
                        echo '<img src="'.$image['imagePath'].'" alt="'.$post["post_id"].'"/>';   
                        if($_SESSION['username'] == $post['username']){
                            echo '<a href="?p=post-Detail&postid='.$post['post_id'].'&deleteimg='.$image['image_id'].'">Delete Image</a>';
                        }
                    }
                }
            }
            else{
                echo '<br>No Image Found.<br/><div class="intro-buttons"><a style="    width: 140px;" href="/WebAppDev/?p=upload-Image">Upload-Image</a></div>';
            }
        ?>
    </div>
<?php
} else{
    do_not_found();
}
?>