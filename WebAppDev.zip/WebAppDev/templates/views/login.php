<?php     
        if(!isset($_SESSION['loginCount'])){
            $_SESSION['loginCount'] = 5;
        }
        if(isset($_POST['submit']) && !isset($_SESSION['auth'])){
            if($_SESSION['loginCount'] != 0){
                 $_SESSION['loginCount']--;
            }
           
            if(!empty($_POST['username']) && !empty($_POST['password'])){
                if(do_login($_POST['username'],$_POST['password'])){
                    $_SESSION['auth'] = true;  
                    $_SESSION['username'] = $_POST['username'];
                    if(is_verified($_SESSION['username'])){
                        header('location: /WebAppDev/?p=explore');
                        exit();
                    }
                    else{
                        header('location: /WebAppDev/?p=verification');
                        exit();
                    }
                }
                else{
                    echo '<div class="error">Wrong Username or Password.</div>';
                }
            }
            else{
                echo '<div class="error">Please enter the valid username and password.</div>';
            }
        }
        if(intval($_SESSION['loginCount']) == 0){
            echo '<div class="error">You can try again in 3 minutes.</div>';
        }
        if(!is_loggedin() && $_SESSION['loginCount'] < 5 && $_SESSION['loginCount'] > 0){
            echo '<div class="error">You have '.$_SESSION['loginCount'].' attemts left.</div>';
        }
        if(!is_loggedin() && $_SESSION['loginCount'] > 0){
?>

<form action="/WebAppDev/?p=login" method="post">
    <span class="note">Please login to Publish or view post details. <br> 
    Not a Member? <a href="/WebAppDev/?p=registration">Register</a>
    </span><br>
    <label>Username: </label><br>
    <input type="text" name="username" max="25"><br>
    <label>Password: </label><br>
    <input type="password" name="password" max="16"><br>
    <input name="submit" type="submit" value="submit">
</form>

<?php } else if(is_loggedin()){
            header('location:/WebAppDev/?p=home');
            exit();
        }
?>