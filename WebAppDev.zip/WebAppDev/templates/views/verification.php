<?php 
    if(isset($_POST['submit'])){
        if(is_user($_SESSION['username']) && !is_verified($_SESSION['username'])){
                if(!empty($_POST['verificationcode'])){
                    if(do_verify($_SESSION['username'],trim(htmlspecialchars($_POST['verificationcode'])))){
                        header('location: /WebAppDev/?p=postfeed');
                    }
                    else{
                        echo 'Wrong Verification Code: Try Again';
                    }
                }
            }
        }
    if(is_verified($_SESSION['username'])){
        header('location: /WebAppDev/?p=postfeed');
    }
?>

<form action="/WebAppDev/?p=verification" method="post">
    <input type="text" name="verificationcode" maxlength="25">
    <input type="submit" name="submit" value="submit"/>
</form>