<?php
$target_dir = "uploads/postimg/";
$uploadOk = 1;
//$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);



if(isset($_POST["submit"])) {
    if(isset($_POST['postid'])){
        if(is_post($_POST['postid'])){
            $filecount = count($_FILES['image']['name']);
            if($filecount > 5){
                $_SESSION['update'] = 'fiveplus';
                header('location: /WebAppDev/?p=upload-Image');
                exit();
            }
            else{
                foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){ 
                    $file_name = $key.$_FILES['image']['name'][$key];
                    $file_size =$_FILES['image']['size'][$key];
                    $file_tmp =$_FILES['image']['tmp_name'][$key];
                    $file_type=$_FILES['image']['type'][$key];
                    $ext = pathinfo($file_name, PATHINFO_EXTENSION);
                    $image_name = generate_image_name($_POST['postid']).'.'.$ext;
                    $target_file = $target_dir . basename($image_name);
                    echo $target_file;
                    if(image_type_check($file_type) && image_size_check($file_size)){  
                        if (move_uploaded_file($file_tmp, $target_file) && insert_image($_POST['postid'],$target_file)) {
                            $filecount--;  
                        }
                    }
                }
                if($filecount == 0){
                    $_SESSION['update'] = 'imagesadded';
                    header('location: /WebAppDev/?p=upload-Image');
                    exit();
                }
                else{
                
                }
            }      
        }
        else{
            $_SESSION['update'] = 'invalidpost';
            header('location: /WebAppDev/?p=upload-Image');
            exit();
        }
    }
    else{
            $_SESSION['update'] = 'invalidpost';
            header('location: /WebAppDev/?p=upload-Image');
            exit();
    }
}

?>


<form style="width: 285px;" action="/WebAppDev/?p=upload-Image" method="post" enctype="multipart/form-data">
        <?php 
            if(isset($_GET['selectedpost'])) {
                echo '<select style="display:none" name="postid">';
                echo '<option value="'.$_GET['selectedpost'].'">'; 
                echo '</select>';
            }
             else{
                 echo '<label>Select Post:</label>';
                 echo '<span style="width:100%" class="note">*Select the post you want the images to be added to.</span>';
                 echo '<select name="postid">';
                 get_post_selection(get_member_id($_SESSION['username']));
                 echo '</select>';
             }
        ?>
    <label>Add Image(s) <span class="addmore" onClick="addmore()">+</span></label><br/>
    <div id="imageinputs">
        <input type="file" name="image[]" id="images">
    </div>
    <span style="width:100%" class="note">*Use the green (+) button to add more fields/images at once.</span><br/>
    <span style="width:100%" class="note">*Maximum 5 images are allowed at once.</span><br>
    <span style="width:100%" class="note">*Maximum image size allowed is 5MB.</span><br/>
    <input type="submit" value="Upload" name="submit">
</form>
<script type='text/javascript'>
    function addmore(){    
        if(document.getElementById("imageinputs").childElementCount <= 4){
            var inputEl = document.createElement("input");
            inputEl.type = "file";
            inputEl.name = "image[]";
            inputEl.id = "images";
            
            document.getElementById("imageinputs").appendChild(inputEl);
        }
        else{
            alert('Maximum 5 images are allowed.');
        }
    }
</script>