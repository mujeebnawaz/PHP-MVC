<?php
    if(isset($_POST['submit']) && !empty($_POST['Captcha']) && trim(htmlspecialchars($_POST['Captcha'])) == $_SESSION['captcha']){
        $error = 7;
        foreach ($_POST as $key => $value){
            if(empty(trim(htmlspecialchars($value)))){
                echo '<div class="error_box">';
                echo 'Please Enter: '. $key;
                echo '</div>';
            }
            else{
                $error--;
            }
        }
        if($error == 0){
            if(isset($_POST['Password']) && isset($_POST['confirmPassword'])){
                if($_POST['Password'] != $_POST['confirmPassword']){
                    echo '<div class="error">Passwords do not match.</div>';
                }
                else{
                    $username = $_POST['Username'];
                    $email = $_POST['Email'];
                    $password = $_POST['Password'];
                    $licence = $_POST['licence'];
                    if(is_email($email)){
                        if(register_user($username,$password,$email,$licence) != 2){
                            $_SESSION['auth'] = true;  
                            $_SESSION['username'] = $_POST['Username'];
                            header('location: /WebAppDev/?p=verification');
                            exit();
                        }
                        else{
                            echo '<div class="error">User Exists, Please choose a different Username.</div>';
                        }
                    }
                    else{
                        echo '<div class="error">Invalid Email. Please change the email and try again.</div>';
                    }
                   
                    
                }
            }
        }
    }
    else if(isset($_POST['submit']) && !empty($_POST['Captcha']) && trim(htmlspecialchars($_POST['Captcha'])) != $_SESSION['captcha']){
        echo '<div class="error">Invalid Captcha</div>';
    }
?>
<div class="registration-form">
 <?php   
    if(!is_loggedin()){
        if(isset($_POST['submit'])){
        echo '
        <form action="/WebAppDev/?p=registration"  method="post">
            <label>Username:</label><br/>
            <input value="'.htmlspecialchars($_POST['Username']).'" type="text" name="Username" minlength="5" maxlength="20"/><br/>
            <label>Password</label><br/>
            <input value="'.htmlspecialchars($_POST['Password']).'" type="password" name="Password" minlength="8" maxlength="20" required/><br/>
            <label>Confirm Password</label><br/>
            <input value="'.htmlspecialchars($_POST['confirmPassword']).'" type="password" name="confirmPassword" minlength="8" maxlength="20" required/><br/>
            <label>Email Address:</label><br/>
            <input value="'.htmlspecialchars($_POST['Email']).'" type="email" name="Email" minlength="5" maxlength="255" required/><br/>
            <label>Do you have licence?</label><br/>
            <select name="licence">
                <option value="Yes">Yes</option>
                <option value="No">No</option>
            </select><br/>
            <label>Enter the following captcha: </label><br/>
            <img src="methods/captcha.php" alt="CAPTCHA"/><br/>
            <input type="text" name="Captcha" minlength="5" maxlength="30" required/><br/>
            <span class="note">*All fields are required.</span><br/>
            <input name="submit" value="Submit" type="submit"/>
        </form>';
        }
        else{
            echo '
        <form action="/WebAppDev/?p=registration"  method="post">
            <label>Username:</label><br/>
            <input type="text" name="Username" minlength="5" maxlength="20"/><br/>
            <label>Password</label><br/>
            <input type="password" name="Password" minlength="8" maxlength="20" required/><br/>
            <label>Confirm Password</label><br/>
            <input type="password" name="confirmPassword" minlength="8" maxlength="20" required/><br/>
            <label>Email Address:</label><br/>
            <input type="email" name="Email" minlength="5" maxlength="255" required/><br/>
            <label>Do you have licence?</label><br/>
            <select name="licence">
                <option value="Yes">Yes</option>
                <option value="No">No</option>
            </select><br/>
            <label>Enter the following captcha: </label>
            <img src="methods/captcha.php" alt="CAPTCHA"/><br>
            <input type="text" name="Captcha" minlength="5" maxlength="30" required/><br>
            <span class="note">*All fields are required.</span><br>
            <input name="submit" value="Submit" type="submit"/>
        </form>';
        }
    }
    else{
        header('location:/WebAppDev/?p=home');
        exit();
    }
    
    ?>
</div>
