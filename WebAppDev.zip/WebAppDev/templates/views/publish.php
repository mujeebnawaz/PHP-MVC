<?php
    if(isset($_POST['submit'])){
        if(!empty($_POST['startingpoint']) && !empty($_POST['destination']) && !empty($_POST['traveltimes']) && !empty($_POST['day']) && !empty($_POST['obtainprovide'])){
            $start = htmlspecialchars(trim($_POST['startingpoint'])); 
            $end = htmlspecialchars(trim($_POST['destination']));
            $times = htmlspecialchars(trim($_POST['traveltimes']));
            $days = htmlspecialchars(trim(compile_days($_POST['day'])));
            $function = htmlspecialchars(trim($_POST['obtainprovide']));
            if(!empty($_POST['message'])){
                $message = htmlspecialchars(trim($_POST['message']));
            }
            else{
                $message = 'NULL';
            }
            $member_id = get_member_id($_SESSION['username']);
            if(make_post($start,$end,$times,$days,$function,$message,$member_id) == 0){ 
                $_SESSION['update'] = 'postadded';
                header('location: /WebAppDev/?p=upload-Image&selectedpost='.$_SESSION['recentpid']);
                exit();
            }
        }
        else{
            echo '<div class="error">Input all required fields.</div>';
        }
    }
?>

<div class="publish-form">
    <span class="note">Only fields marked with (*) are required.</span>
    <form method="post" action="/WebAppDev/?p=publish">
        <label>Starting Point:*</label>
        <span style="width:100%" class="note">*Only Greenwich area is allowed.</span><br>
        <input name="startingpoint" type="text" maxlength="12" placeholder="Postcode" required>
        <label>Destination:*</label>
        <input name="destination" type="text" maxlength="12" placeholder="Postcode" required>
        <label>Travel Times:*</label>
        <textarea name="traveltimes" placeholder="Enter Travel Time each on a new line i.e 
9am to 5pm 
8am to 1pm" required></textarea>
        <label>Days:*</label>
        <fieldset class="days-field">
            <input type="checkbox" name="day[]" value="Monday"/> <label>Monday</label><br/>
            <input type="checkbox" name="day[]" value="Tuesday"/> <label>Tuesday</label>
            <br/>
            <input type="checkbox" name="day[]" value="Wednesday"/><label>Wednesday</label><br/>
            <input type="checkbox" name="day[]" value="Thursday"/> <label>Thursday</label> <br />
            <input type="checkbox" name="day[]" value="Friday"/> <label>Friday</label><br/>
            <input type="checkbox" name="day[]" value="Saturday"/> <label>Saturday</label><br/>
            <input type="checkbox" name="day[]" value="Sunday"/> <label>Sunday</label><br/>
        </fieldset>
        <label>Type:*</label><br>
        <span style="width:100%" class="note">*Select if you want to provide or obtain a lift.</span><br>
        <select name="obtainprovide">
            <option value="1">Obtain</option>
            <option value="0">Provide</option>
        </select>
        <label>Message:</label>
        <textarea name="message" placeholder="Enter any especial requirement"></textarea>
        <input type="submit" name="submit" value="Submit"/>
    </form>
</div>