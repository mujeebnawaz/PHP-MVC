<div class="all-posts">
    
   <?php 
        $posts = 0;
        if(!isset($_GET["filter"])){        
            $posts = get_posts(false,true,NULL);
        }
        else if(isset($_GET["filter"])){
             $post = get_posts($_GET["filter"],true,NULL);
        }
        if(count($posts) > 1){
            foreach($posts as $post) { 
    ?>
    <div class="post-row">
        <div class="user_details col">
            <span class="explore-username">Username: <?= $post['username']; ?></span><br/>
            <span class="explore-email">Email: <?= $post['email']; ?></span><br/>
            <span class="drivingLicence">Has driving licence?: <?= $post['drivingLicence']; ?></span><br/>
        </div>
        <div class="post-meta col">
            <span class="startingPoint">Starting Point: <?= $post['startingPoint']; ?></span><br/>
            <span class="startingPoint">Destination: <?= $post['destination']; ?></span><br/>
            <span class="travelTime">Traveling time: <?= $post['travelTimes']; ?></span><br/>
            <span class="travelDays">Days: <?= $post['days']; ?></span><br/>
            <span class="obtainP">Wants to <?= ($post['obtainProvide'])? 'Obtain':'Provide'; ?> the lift.</span><br/>
        </div>
        <a href="?p=post-Detail&postid=<?= $post['post_id']; ?> "class="learnmore">View Details ></a>
    </div>
    <?php } 
        echo '<div class="pagination">'.do_pagination().'</div>';
        }
        else{
    ?>
       <div class="post-row">
        <div class="user_details col">
            <span class="explore-username">Username: <?= $post['username']; ?></span><br/>
            <span class="explore-email">Email: <?= $post['email']; ?></span><br/>
            <span class="drivingLicence">Has driving licence?: <?= $post['drivingLicence']; ?></span><br/>
        </div>
        <div class="post-meta col">
            <span class="startingPoint">Starting Point: <?= $post['startingPoint']; ?></span><br/>
            <span class="startingPoint">Destination: <?= $post['destination']; ?></span><br/>
            <span class="travelTime">Traveling time: <?= $post['travelTimes']; ?></span><br/>
            <span class="travelDays">Days: <?= $post['days']; ?></span><br/>
            <span class="obtainP">Wants to <?= ($post['obtainProvide'])? 'Obtain':'Provide'; ?> the lift.</span><br/>
        </div>
        <a href="?p=post-Detail&postid=<?= $post['post_id']; ?> "class="learnmore">View Details ></a>
    </div>
</div>
<?php }?>
