<?php  
    $profile = htmlspecialchars($_GET['un']);
    $thisProfile = "/WebAppDev/?p=profile&un=".$_SESSION['username'];
    $profileVal = 0;
    $is_sameUser = false;
    $carVal = false;
    $values = NULL;
    if(isset($_GET['un'])){
        if(!empty($profile)){
            if(is_user($profile) && is_verified($profile)){
                extract(get_user_(get_member_id($_GET['un']),"details"));
                $profileVal = 1; // user exists and is verified
                if($profile == $_SESSION['username']){
                    $is_sameUser = true;
                    if(isset($_GET['edit'])){
                        if($_GET['edit'] == 'userDetails'){
                            $profileVal = 3;
                        }
                        else if($_GET['edit'] == 'cars'){
                            $profileVal = 2;
                        }                        
                    }
                    if(isset($_POST['editEmail']) && $is_sameUser){
                        if(!empty($_POST['editedEmail']) && is_email($_POST['editedEmail']))
                        {
                            $newEmail = htmlspecialchars($_POST['editedEmail']);
                            if(update_email($_SESSION['username'],$newEmail)){
                                $_SESSION['update'] = 'email';
                                header('location: /WebAppDev/?p=profile&un='.$_SESSION['username']);
                                exit();
                            }
                            else
                            {
                                $_SESSION['update'] = 'emailerror';
                            }

                        }
                        else{ 
                                $_SESSION['update'] = 'emailerror';
                        }
                    }
                    if(isset($_POST['addCar']) && $is_sameUser){
                        $carMake = htmlspecialchars(trim($_POST['car-make']));
                        $carModel = htmlspecialchars(trim($_POST['car-model']));
                        $carReg = htmlspecialchars(trim($_POST['car-registration']));
                        $carIns = htmlspecialchars(trim($_POST['insurance']));
                        if(!empty($carMake) && !empty($carModel) && !empty($carReg) && !empty($carIns)){
                            if(add_car($carMake,$carModel,$carReg,$carIns,get_member_id($_SESSION['username']))){
                                $_SESSION['update'] = 'car';
                                header('location: /WebAppDev/?p=profile&un='.$_SESSION['username']);
                                exit();
                            }
                            else{
                                $_SESSION['update'] = 'carerror';
                            }
                        }
                        else{
                                $_SESSION['update'] = 'required';
                        }
                    }
                    if(isset($_POST['editPassword']) && $is_sameUser){
                        if(!empty($_POST['password']) && !empty($_POST['currentPassword'])){
                            if(change_password($_POST['currentPassword'],$_POST['password'],$_SESSION['username'])){
                                $_SESSION['update'] = 'password';
                                header('location: /WebAppDev/?p=profile&un='.$_SESSION['username']);
                                exit();
                            }
                            else{
                                $_SESSION['update'] = 'passworderror';
                            }
                        }
                        else{
                                $_SESSION['update'] = 'required';
                        }
                    }
                }
                if(get_user_(get_member_id($_GET['un']),"cars") != NULL){
                    $values = get_user_(get_member_id($_GET['un']),"cars");
                    $carVal = true;
                }
            }
            else{
                echo 'User Doesnt Exist';
            }
        }
        else{
            echo 'Invalid Username';
        }
    }
    else{
        header('location: /WebAppDev/?p=home');
        exit();
    }
?>
<?php if($profileVal == 1) {?>
        <div class="user-profile">
            <span class="username"><?= $username ?></span><br/>
            <span class="up-email">Email: <?= $email ?></span><br/>
            <span class="up-dl">Driving Licence: <?= $drivingLicence ?></span><br/>
        </div>
    <div class="user-cars">
        <h2>Existing car details.</h2>
        <?php if($carVal) { ?>
        <span class="cars">
                <?php
                    foreach($values as $value){
                        echo 'Make: '.$value['make'].'<br>';
                        echo 'Model: '.$value['model'].'<br>';
                        echo 'Registeration: '.$value['registrationNumber'].'<br>';
                        echo 'Insurance: '.($value['insuranceStatus']? 'Yes' : 'No').'<br>';
                        echo '<br/>';
                    }
                ?>
        </span>
        <?php } else {
                echo '<span class="cars">No Car Exist.</span>';
            }      
        ?>
    </div>
    <div class="posts">
        
    </div>
    <?php if($is_sameUser) {?>
        <div class="edit-buttons">
            <a href="/WebAppDev/?p=profile&un=<?php echo $_SESSION['username']; ?>&edit=cars">Add Cars ></a><br/>
             <label>Info: Add a car to use for your posts.</label><br/>
            <a style="margin-top: 30px" href="/WebAppDev/?p=profile&un=<?php echo $_SESSION['username']; ?>&edit=userDetails">Edit Profile ></a><br/>
            <label>Info: Change your email or password.</label><br/>
        </div>
    <?php } ?>

<?php } if($profileVal == 2) { ?>
    <div class="edit-cars">
            <h2>Add a Car</h2>
            <span class="note">All fields are required.</span>
                <form action="/WebAppDev/?p=profile&un=<?php echo $_SESSION['username']; ?>&edit=cars" method="post"> 
                    <label>Car Make:</label><br/>
                    <input type="text" name="car-make" maxlength="30" required/><br/>
                    <label>Car Model:</label><br/>
                    <input type="text" name="car-model" maxlength="30" required/><br/>
                    <label>Car Registration:</label><br/>
                    <input type="text" name="car-registration" minlength="4" maxlength="10" required><br/>
                    <label>Car Insurance:</label><br/>
                    <select name="insurance">
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select><br/>
                    <input type="submit" name="addCar" value="Submit" >
                </form>
        <h2>Existing car details.</h2>
        <?php if($carVal) { ?>
            <span class="cars">
                <?php
                    foreach($values as $value){
                        echo 'Make: '.$value['make'].'<br>';
                        echo 'Model: '.$value['model'].'<br>';
                        echo 'Registeration: '.$value['registrationNumber'].'<br>';
                        echo 'Insurance: '.($value['insuranceStatus']? 'Yes' : 'No').'<br>';
                        echo '<br/>';
                    }
                ?>
            </span>
        <?php } else {
                echo '<span class="cars">No Car Exist.</span>';
            }      
        ?>
    </div>

<?php } if($profileVal == 3) { ?>
    <h2>Edit Email</h2>
    <div class="edit-email">
        <form action="/WebAppDev/?p=profile&un=<?php echo $_SESSION['username']; ?>&edit=userDetails" method="post">
            <label>New Email:*</label><br>
            <input type="email" name="editedEmail" required><br>
            <input type="submit" name="editEmail" value="submit">
        </form>
    </div>
    <h2>Edit Password</h2>
    <div class="edit-password">
        <form action="/WebAppDev/?p=profile&un=<?php echo $_SESSION['username']; ?>&edit=userDetails" method="post">
            <label>Enter your current password:*</label><br>
            <input type="password" name="currentPassword" minlength="8" required><br>
            <label>Enter your new password:*</label><br>
            <input type="password" name="password" minlength="8" maxlength="16" required><br>
            <input type="submit" name="editPassword" value="submit">
        </form>
    </div>
<?php } ?>

