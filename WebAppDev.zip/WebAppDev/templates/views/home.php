<div class="introduction">
    <div class="intro-image">
        <img src="files/caranim.gif" alt="Car Image"/>
    </div>
    <div class="intro-text">
        Greenwich Carpool allows people to share the cars of neighbours in terms of mutual journeys and time. Simply just register, 
        and Start exploring the journeys that you can share with others.<br>
        <div class="intro-buttons">
            <a href="/WebAppDev/?p=explore&page=1">Explore ></a><br/>
            <?php if(!is_loggedin()){?>
            <a href="/WebAppDev/?p=registration">Register ></a><br/>
            <a href="/WebAppDev/?p=login">Login ></a>
            <?php } ?>
        </div><br/><br/>
        <h2>Search the Posts</h2><br/>
        <script type="text/javascript">
    function search(){
        alert(document.getElementById("filter").nodeValue);
    }
</script>
        <form method="get" action="/WebAppDev/?p=explore&page=1/">
            <input id="filter" type="text" name="filter" placeholder="Keywords"/>
            <input type="submit" value="Search"/>
        </form>
    </div>
</div>
