<!DOCTYPE html>
<html>
    <head>
        <!-- Header Used in all templates 
            Incorporates:
            Google Fonts,
            Responsive Style sheet (with media queries).

        -->
        <link type="text/css" rel="stylesheet" href="scripts/style.css">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet">
        <meta name="viewport" content="initial-scale=1.0, width=device-width">
    </head>
    <body>
       <?php 
            //Dynamic Navigation Array, with Page Name and Page link in each array.
            $profile = NULL; 
            if(isset($_SESSION['username'])){$profile = $_SESSION['username'];}
            // checks if the current user is logged in
            $pages = array(
                array(
                    "Home",
                    "/WebAppDev/?p=home"
                    ),
                array("Explore",
                      "/WebAppDev/?p=explore&page=1"
                     ),
                array("Publish",
                      "/WebAppDev/?p=publish"
                     ),
                array("Profile",
                     "/WebAppDev/?p=profile&un=".$profile)
            );
            echo '<header class="site-header">';
            echo '<div class="header-wrapper">';
            echo '<div class="logo"><a href="/WebAppDev/?p=home"><span class="greenwich">Greenwich</span> <span class="pool">CarPool</span></a></div>';
            
                if(is_loggedin()) { //checks if user is loggedin
                    echo '<div class="menu" onClick="menu_visible()">Menu</div>';
                    doNavigation($pages); //generates the dynamic navigation
                    echo '<span class="log">
                            <a href="?p=logout">Logout</a>
                          </span>';
                }
                if(is_loggedin() && is_verified($_SESSION['username'])){ //checks if user is logged in and verified
                    echo '<span class="log">';
                        echo 'Welcome, '.$_SESSION['username'].' | ';
                    echo '<a href="?p=logout">Logout</a>
                          </span>';
               }
                else if(!is_loggedin()){
                     echo '<span class="log">
                            <a href="?p=login">Login</a> |  <a href="?p=registration">Register</a> 
                          </span>';
                }
               
            echo '</div>';
            echo '</header>';
            if(is_loggedin() && !is_verified($_SESSION['username']) && $_GET['p'] != 'verification'){
                            header('location: /WebAppDev/?p=verification');
            }
            else if (!is_loggedin() && $_GET['p'] != 'login' && $_GET['p'] != 'home' && $_GET['p'] != 'registration' && $_GET['p'] != 'explore' && $_GET['p'] != '404'){
                header('location: ?p=login');
            }

        ?>
        
        <div class="wrapper" id="main">
            <div class="inner-wrapper">
                <div class="title">
                    <h1><?php get_title(); ?></h1>
                </div>
                <?php   do_error();   ?>