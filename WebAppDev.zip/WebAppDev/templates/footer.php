            </div>
        </div>
        <script type="text/javascript">
            document.body.style.minHeight = window.innerHeight+'px';
            if(screen.width <= 500){
                <?php if(is_loggedin()) {?>
                document.getElementById("primary-navigation").style.display = "none";
                <?php } ?>
            }
            function menu_visible(){
                var target = document.getElementById("primary-navigation");
                    if (target.style.display === "none") {
                        target.style.display = "block";
                    } else {
                        target.style.display = "none";
                    }
            }
        </script>
        <footer>
            <span class="credits">COPYRIGHT © 2017 000909728 - University of Greenwich</span>
        </footer>
    </body>
</html>