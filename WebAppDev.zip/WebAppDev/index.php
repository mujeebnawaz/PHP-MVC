<?php error_reporting( E_ALL ); ?>
<?php 
include 'methods/functions.php';
    get('header');
        if(isset($_GET['filter']) && $_GET['p'] != 'explore'){
            header('location: ?p=explore&page=1&filter=message:'.$_GET['filter']);
        }
        if(isset($_GET['p'])){
            switch($_GET['p']){
                case "registration":
                    get('/views/registration');
                    break;
                case "404":
                    get('/views/not-found');
                break;
                case "login":
                    get('/views/login');
                    break;
                case "explore":
                    get('/views/explore');
                    break;
                case "profile":
                    get('/views/profile');
                    break;
                case "verification":
                    get('/views/verification');
                    break;
                case "logout":
                    session_destroy();
                    header('location: /WebAppDev/');
                    break;
                case "home":
                    get('/views/home');
                    break;
                case "publish":
                    get('/views/publish');
                break;
                case "post-Detail":
                    get('/views/post-detail');
                break;
                case "upload-Image":
                    get('/views/image');
                break;   
            }
        }
    get('footer');

?>


